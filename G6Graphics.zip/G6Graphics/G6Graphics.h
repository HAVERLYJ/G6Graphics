#include <iostream>
#include "tigr.c"
#include <stdlib.h>
#include <string>


using namespace std;

//HELP FUNCTION//
int G6help()
{
    cout<<"DESCRIPTIONS OF HOW G6 FUNCTIONS ARE CALLED"<<endl<<endl;
    cout<<"---G6arrayDisplay---"<<endl<<"____________________"<<endl; 
    cout<<"Function Call: G6arrayDisplay(userArray,arrSize);"<<endl<<endl;
    cout<<"Parameters: userArray: The name of your integer array"<<endl;
    cout<<"            arrSize: The expected size of your array"<<endl;
    cout<<"Result: A display that shows your array values"<<endl;
    cout<<"        and the order they appear in the array"<<endl<<endl<<endl;
    return 0;
}

//ARRAY FUNCTION//
int G6arrayDisplay(int *userArray, int arrSize)
{   
    int doneCycle = 0,ycord = 0,nextLine = 0;
    
    //DYNAMIC VARIABLES//
    string stringArr[arrSize];
    const char* charArr[arrSize];
    string position;
    const char* pos;

    //Populating S&C Arrays//
    for(int a = 0; a < arrSize; a++)
    {  stringArr[a] = to_string(userArray[a]);
       charArr[a] = stringArr[a].c_str();
    }

    //Create Display Screen//
    Tigr *screen = tigrWindow(620, 400, "CS-370 PROJECT", 0);
    tigrClear(screen, tigrRGB(156,156,168));

    while (!tigrClosed(screen) && !tigrKeyDown(screen, TK_ESCAPE))
    { tigrClear(screen, tigrRGB(156,156,168));

    ycord = 0;
      nextLine = 0;
      if(doneCycle !=1)
      {
        for(int b = 0; b<arrSize;b++)
        {   //Show Array Elements
            tigrClear(screen, tigrRGB(156,156,168));
            nextLine = 0;
            ycord = 0;
            for(int d = 0; d<=b;d++)
            {   
                tigrPrint(screen, tfont, 217,10 , tigrRGB(0xff, 0xff, 0xff), "How Your Array Populated");  
                if(nextLine == 8)
                {
                    ycord += 50;
                    nextLine = 0; 
                }

                position = to_string(d);
                pos = position.c_str();

                //Displaying the stuff
                tigrRect(screen, 200, 40, 20, 15, tigrRGB(255, 0, 0));
                tigrPrint(screen, tfont, 220, 40, tigrRGB(0xff, 0xff, 0xff), " = The Position in The Array");
                tigrRect(screen, 75*(nextLine)+65, 70+ycord-5, 20, 15, tigrRGB(255, 0, 0));
                tigrRect(screen, 75*(nextLine)+10, 70+ycord-5, 75, 50, tigrRGB(0, 0, 255));
                tigrPrint(screen, tfont, 75*(nextLine)+10+15, 70+ycord+20, tigrRGB(0xff, 0xff, 0xff), charArr[d]);
                tigrPrint(screen, tfont, 75*(nextLine)+67, 70+ycord-2, tigrRGB(0xff, 0xff, 0xff), pos);
                nextLine++;
            }
            #ifdef _WIN32
	        Sleep(2000);
            #else
	        struct timespec ts;

	        ts.tv_sec = 2000 / 1000;
	        ts.tv_nsec = (2000 %1000) * 1000000L;

	        if(nanosleep(&ts, NULL) < 0) {
		        perror("sleep failed");
	        }
            #endif /* _WIN32 */
                tigrUpdate(screen);
        }
       doneCycle = 1;
    }
    else
      {
        tigrPrint(screen, tfont, 200,10 , tigrRGB(0xff, 0xff, 0xff), "How Your Array Populated");  
        nextLine = 0; 
        for(int b = 0; b<arrSize;b++)
        {   //Show Array Elements
            tigrRect(screen, 217, 40, 20, 15, tigrRGB(255, 0, 0));
            tigrPrint(screen, tfont, 220, 40, tigrRGB(0xff, 0xff, 0xff), " = The Position in The Array");
            if(nextLine == 8)
            {
                ycord += 50;
                nextLine = 0;
            }
                position = to_string(b);
                pos = position.c_str();
                tigrRect(screen, 75*(nextLine)+65, 70+ycord-5, 20, 15, tigrRGB(255, 0, 0));
                tigrRect(screen, 75*(nextLine)+10, 70+ycord-5, 75, 50, tigrRGB(0, 0, 255));
                tigrPrint(screen, tfont, 75*(nextLine)+10+15, 70+ycord+20, tigrRGB(0xff, 0xff, 0xff), charArr[b]);
                tigrPrint(screen, tfont, 75*(nextLine)+67, 70+ycord-2, tigrRGB(0xff, 0xff, 0xff), pos);
            nextLine++;                   
        }
      }
        tigrUpdate(screen); 
    }
    tigrFree(screen);  
    
    return 0;    
}