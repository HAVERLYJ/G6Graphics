#include <iostream>
#include "G6Graphics.h"

using namespace std;

int main(int argc, char *argv[])
{
   int arr[7] = {5,4,9,3,1,5,4};
   int n = sizeof(arr) / sizeof(arr[0]);

    G6BarGraph(arr,n);

    return 0;

}