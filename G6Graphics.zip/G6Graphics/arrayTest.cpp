#include <iostream>
#include "G6Graphics.h"

using namespace std;

int main(int argc, char *argv[])
{
    int arr[3] = {20311,4224,19};
    G6arrayDisplay(arr,3);
    int fee = tigrTextWidth(tfont, "Array");
    cout<<fee;
    return 0;

}